(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
})();
document.addEventListener("DOMContentLoaded", async () => {
  const statusBadge = document.getElementById("tracking-status");
  const timerSpan = document.getElementById("tracking-timer");
  const problemInfoDiv = document.getElementById("problem-info");
  const problemNameSpan = document.getElementById("problem-name");
  const problemRunsSpan = document.getElementById("problem-runs");
  const problemLangSpan = document.getElementById("problem-lang");
  const emailInput = document.getElementById("user-email");
  const btnSimulate = document.getElementById("btn-simulate");
  const simProfileSelect = document.getElementById("sim-profile");
  const stored = await chrome.storage.local.get(["userEmail"]);
  if (stored.userEmail) {
    emailInput.value = stored.userEmail;
  } else {
    await chrome.storage.local.set({ userEmail: emailInput.value });
  }
  emailInput.addEventListener("input", async () => {
    await chrome.storage.local.set({ userEmail: emailInput.value });
  });
  const updateUI = async () => {
    const data = await chrome.storage.local.get([
      "trackingState",
      "elapsedSeconds",
      "problemTitle",
      "runCount",
      "language"
    ]);
    if (data.trackingState === "TRACKING") {
      statusBadge.textContent = "Tracking";
      statusBadge.className = "status-badge status-tracking";
      problemInfoDiv.style.display = "block";
      problemNameSpan.textContent = data.problemTitle || "LeetCode Problem";
      problemRunsSpan.textContent = String(data.runCount || 0);
      problemLangSpan.textContent = data.language || "C++";
      const seconds = data.elapsedSeconds || 0;
      const mins = Math.floor(seconds / 60);
      const secs = seconds % 60;
      timerSpan.textContent = `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
    } else {
      statusBadge.textContent = "Idle";
      statusBadge.className = "status-badge status-idle";
      timerSpan.textContent = "00:00";
      problemInfoDiv.style.display = "none";
    }
  };
  updateUI();
  setInterval(updateUI, 1e3);
  btnSimulate.addEventListener("click", async () => {
    const type = simProfileSelect.value;
    const email = emailInput.value;
    btnSimulate.disabled = true;
    btnSimulate.textContent = "Simulating...";
    chrome.runtime.sendMessage(
      {
        action: "SIMULATE_SESSION",
        payload: { type, email }
      },
      (response) => {
        btnSimulate.disabled = false;
        btnSimulate.textContent = "Inject Simulation Logs";
        if (response && response.success) {
          alert(`Successfully simulated "${type.toUpperCase()}" session! Check your CodeLens dashboard.`);
        } else {
          alert(`Failed to simulate session: ${(response == null ? void 0 : response.error) || "Server offline"}`);
        }
      }
    );
  });
});
